echo adding a new line
echo adding last line
