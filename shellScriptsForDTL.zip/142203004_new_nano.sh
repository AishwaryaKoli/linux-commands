#!/bin/bash
    
echo 'This is Hello world bash script.'
echo 'Hello World!'
echo 'This is written for script execution using SheBang (#!)'
