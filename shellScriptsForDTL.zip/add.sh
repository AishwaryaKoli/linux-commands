#!/bin/bash

read a
read b
c=$(($a+$b))
echo $a + $b = $c
