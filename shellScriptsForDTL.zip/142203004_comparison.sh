#!/bin/bash

string_a="UNIX"
string_b="GNU"
echo "Are $string_a and $string_b strings equal?" [ $string_a = $string_b ]
echo $?
