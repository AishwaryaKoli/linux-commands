#!/bin/bash

a=1
b=2
echo [$a -lt $b]
echo $?
echo [$a -gt $b]
echo $?
echo [$a -eq $b]
echo $?
echo [$a -ne $b]
echo $?


