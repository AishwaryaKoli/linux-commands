#!/bin/bash

let a=1+2
let b=5*6
let c=12/4
let d=5-999

echo $a $b $c $d
